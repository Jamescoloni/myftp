MyFTP 1.3 ReadMe File

#Fixed Some Bugs

#Upload Multiple Files (Still Under Development)

#File Upload Is Powered By ZeUploadX

#Changed The Entire Design Of MyFTP

#some features are coming soon
